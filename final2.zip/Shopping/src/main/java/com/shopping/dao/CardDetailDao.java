package com.shopping.dao;

import com.shopping.model.CardDetail;


public interface CardDetailDao {

    void addCardDetail (CardDetail cardDetail);

}
