package com.shopping.service;

import com.shopping.model.CardDetail;



public interface CardDetailService {

    void addCardDetail (CardDetail carddetail);

}
