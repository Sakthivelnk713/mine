package com.shopping.dao;

import com.shopping.model.UserOrder;


public interface OrderDao {

    void addOrder(UserOrder userOrder);

}
